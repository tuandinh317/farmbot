from database import get_user, add_user, add_ref_bonus

def register(bot):

    @bot.message_handler(commands=['start'])
    def start(message):
        user_id = str(message.from_user.id)

        args = message.text.split()
        ref_id = args[1] if len(args) > 1 else None

        user, _ = get_user(user_id)

        if user:
            bot.reply_to(message, "🌾 Bạn đã tham gia rồi!")
            return

        if ref_id == user_id:
            ref_id = None

        add_user(user_id, ref_id)

        if ref_id:
            add_ref_bonus(ref_id)

        bot.reply_to(message,
            "🌾 Chào mừng đến Farm VND!\n"
            "Bạn nhận 10,000 VNĐ khởi đầu.\n"
            "Dùng /farm để xem trang trại."
        )