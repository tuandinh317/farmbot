from database import get_user, format_vnd

def register(bot):

    @bot.message_handler(commands=['farm'])
    def farm(message):
        user_id = str(message.from_user.id)
        user, _ = get_user(user_id)

        if not user:
            bot.reply_to(message, "Dùng /start trước.")
            return

        msg = (
            f"💵 Số dư: {format_vnd(user['vnd'])}\n"
            f"⚡ Energy: {user['energy']}\n"
            f"🏡 Đất: {user['land']}\n"
            f"⭐ Level: {user['level']}\n"
            f"🏆 Rank: {user['rank']}\n"
            f"📈 EXP: {user['exp']}\n"
            f"👥 Ref: {user['ref_count']}"
        )

        bot.reply_to(message, msg)