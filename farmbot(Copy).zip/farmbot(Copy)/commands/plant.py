import time
from database import get_user, users_sheet, crops_sheet

def register(bot):

    @bot.message_handler(commands=['plant'])
    def plant(message):
        user_id = str(message.from_user.id)
        user, row_index = get_user(user_id)

        if not user:
            bot.reply_to(message, "Dùng /start trước.")
            return

        if int(user["energy"]) <= 0:
            bot.reply_to(message, "⚡ Không đủ năng lượng!")
            return

        plant_time = int(time.time())
        harvest_time = plant_time + 60

        crops_sheet.append_row([
            user_id,
            "lua",
            plant_time,
            harvest_time,
            0
        ])

        new_energy = int(user["energy"]) - 1
        users_sheet.update(f"C{row_index}", new_energy)

        bot.reply_to(message, "🌱 Đã trồng lúa! 60 giây nữa thu hoạch.")