import telebot
from config import BOT_TOKEN

bot = telebot.TeleBot(BOT_TOKEN)

from commands import start, farm, plant, harvest, invite

start.register(bot)
farm.register(bot)
plant.register(bot)
harvest.register(bot)
invite.register(bot)

print("Bot đang chạy...")
bot.infinity_polling()