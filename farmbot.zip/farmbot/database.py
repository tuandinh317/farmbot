import psycopg
from psycopg2.extras import RealDictCursor
from config import DATABASE_URL

conn = psycopg.connect(DATABASE_URL)
conn.autocommit = True


def init_db():
    with conn.cursor() as cur:
        cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            telegram_id BIGINT UNIQUE NOT NULL,
            username TEXT,
            vnd BIGINT DEFAULT 10000,
            farm_level INT DEFAULT 1,
            exp INT DEFAULT 0,
            rank TEXT DEFAULT 'Nông dân',
            ref_id BIGINT,
            ref_count INT DEFAULT 0,
            is_banned BOOLEAN DEFAULT FALSE,
            last_plant TIMESTAMP,
            last_harvest TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id SERIAL PRIMARY KEY,
            telegram_id BIGINT,
            amount BIGINT,
            type TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)


def get_user(tid):
    with conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute("SELECT * FROM users WHERE telegram_id=%s", (tid,))
        return cur.fetchone()


def create_user(tid, username, ref_id=None):
    with conn.cursor() as cur:
        cur.execute("""
        INSERT INTO users (telegram_id, username, ref_id)
        VALUES (%s, %s, %s)
        ON CONFLICT DO NOTHING
        """, (tid, username, ref_id))

        if ref_id:
            cur.execute("""
            UPDATE users
            SET vnd = vnd + 3000,
                ref_count = ref_count + 1
            WHERE telegram_id=%s
            """, (ref_id,))


def update_money_exp(tid, money, exp):
    with conn.cursor() as cur:
        cur.execute("""
        UPDATE users
        SET vnd = vnd + %s,
            exp = exp + %s,
            farm_level = (exp + %s)/5 + 1
        WHERE telegram_id=%s
        """, (money, exp, exp, tid))

        cur.execute("""
        INSERT INTO transactions (telegram_id, amount, type)
        VALUES (%s, %s, %s)
        """, (tid, money, "harvest"))


def update_timestamp(tid, column):
    with conn.cursor() as cur:
        cur.execute(f"""
        UPDATE users SET {column}=NOW() WHERE telegram_id=%s
        """, (tid,))


def get_top(limit=10):
    with conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute("""
        SELECT telegram_id, vnd
        FROM users
        ORDER BY vnd DESC
        LIMIT %s
        """, (limit,))
        return cur.fetchall()


def ban_user(tid):
    with conn.cursor() as cur:
        cur.execute("UPDATE users SET is_banned=TRUE WHERE telegram_id=%s", (tid,))