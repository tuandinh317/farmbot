import telebot
from config import BOT_TOKEN
from database import init_db

bot = telebot.TeleBot(BOT_TOKEN)

init_db()

from commands import start, farm, plant, harvest, invite, leaderboard, admin

start.register(bot)
farm.register(bot)
plant.register(bot)
harvest.register(bot)
invite.register(bot)
leaderboard.register(bot)
admin.register(bot)

print("🚀 FarmBot PRO PostgreSQL running...")
bot.infinity_polling(skip_pending=True)