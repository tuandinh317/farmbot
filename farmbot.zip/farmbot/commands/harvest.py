import random
from database import get_user, update_money_exp, update_timestamp
from datetime import datetime

COOLDOWN = 15

def register(bot):

    @bot.message_handler(commands=['harvest'])
    def harvest_cmd(message):
        user = get_user(message.from_user.id)

        if not user:
            return

        if user["last_harvest"]:
            diff = datetime.now() - user["last_harvest"]
            if diff.total_seconds() < COOLDOWN:
                bot.reply_to(message, "⏳ Cây chưa chín.")
                return

        earn = random.randint(1000, 3000)

        update_money_exp(user["telegram_id"], earn, 1)
        update_timestamp(user["telegram_id"], "last_harvest")

        bot.reply_to(message, f"🌾 +{earn:,} VNĐ")