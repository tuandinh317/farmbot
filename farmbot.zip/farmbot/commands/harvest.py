import time
from database import (
    get_user,
    users_sheet,
    crops_sheet,
    calculate_level,
    calculate_rank,
    format_vnd
)

def register(bot):

    @bot.message_handler(commands=['harvest'])
    def harvest(message):
        user_id = str(message.from_user.id)
        data = crops_sheet.get_all_records()
        now = int(time.time())
        harvested_any = False

        for i, row in enumerate(data):
            if (
                str(row["user_id"]) == str(user_id)
                and int(row["harvested"]) == 0
                and now >= int(row["harvest_time"])
            ):

                crops_sheet.update(f"E{i+2}", 1)

                user, row_index = get_user(user_id)

                exp = int(user["exp"]) + 1
                level = calculate_level(exp)
                rank = calculate_rank(level)

                base_vnd = 1200

                if level >= 20:
                    base_vnd += 800
                elif level >= 12:
                    base_vnd += 500
                elif level >= 8:
                    base_vnd += 300
                elif level >= 3:
                    base_vnd += 200

                new_vnd = int(user["vnd"]) + base_vnd

                users_sheet.update(f"B{row_index}", new_vnd)
                users_sheet.update(f"F{row_index}", exp)
                users_sheet.update(f"E{row_index}", level)
                users_sheet.update(f"G{row_index}", rank)

                harvested_any = True

        if harvested_any:
            bot.reply_to(message, f"🌾 Thu hoạch thành công! +{format_vnd(base_vnd)}")
        else:
            bot.reply_to(message, "Chưa có cây nào thu hoạch được.")