from database import get_user, update_timestamp
from datetime import datetime, timedelta

COOLDOWN = 10

def register(bot):

    @bot.message_handler(commands=['plant'])
    def plant_cmd(message):
        user = get_user(message.from_user.id)

        if not user:
            return

        if user["last_plant"]:
            diff = datetime.now() - user["last_plant"]
            if diff.total_seconds() < COOLDOWN:
                bot.reply_to(message, "⏳ Chờ thêm chút.")
                return

        update_timestamp(user["telegram_id"], "last_plant")

        bot.reply_to(message, "🌱 Đã trồng cây.")