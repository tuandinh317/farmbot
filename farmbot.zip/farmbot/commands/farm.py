from database import get_user

def register(bot):

    @bot.message_handler(commands=['farm'])
    def farm_cmd(message):
        user = get_user(message.from_user.id)

        if not user:
            bot.reply_to(message, "Dùng /start trước.")
            return

        if user["is_banned"]:
            return

        bot.reply_to(
            message,
            f"💰 {user['vnd']:,} VNĐ\n"
            f"⭐ EXP: {user['exp']}\n"
            f"🏡 Level: {user['farm_level']}\n"
            f"👑 Rank: {user['rank']}\n"
            f"👥 Ref: {user['ref_count']}"
        )