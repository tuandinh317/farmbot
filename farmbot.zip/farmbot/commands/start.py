from database import get_user, create_user

def register(bot):

    @bot.message_handler(commands=['start'])
    def start_cmd(message):
        tid = message.from_user.id
        username = message.from_user.username
        args = message.text.split()

        ref_id = int(args[1]) if len(args) > 1 else None

        if get_user(tid):
            bot.reply_to(message, "🌾 Bạn đã tham gia rồi!")
            return

        create_user(tid, username, ref_id)

        bot.reply_to(message, "🌾 Chào mừng! Bạn nhận 10,000 VNĐ.")