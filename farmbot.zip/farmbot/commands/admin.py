from config import ADMIN_ID
from database import ban_user

def register(bot):

    @bot.message_handler(commands=['ban'])
    def ban_cmd(message):
        if message.from_user.id != ADMIN_ID:
            return

        args = message.text.split()

        if len(args) < 2:
            return

        tid = int(args[1])
        ban_user(tid)

        bot.reply_to(message, "User đã bị ban.")