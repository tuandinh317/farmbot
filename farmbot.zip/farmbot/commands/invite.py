def register(bot):

    @bot.message_handler(commands=['invite'])
    def invite_cmd(message):
        username = bot.get_me().username
        link = f"https://t.me/{username}?start={message.from_user.id}"
        bot.reply_to(message, f"👥 Link mời:\n{link}")