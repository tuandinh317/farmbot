from database import get_user, format_vnd

def register(bot):

    @bot.message_handler(commands=['invite'])
    def invite(message):
        user_id = str(message.from_user.id)
        user, _ = get_user(user_id)

        if not user:
            bot.reply_to(message, "Dùng /start trước.")
            return

        bot_username = bot.get_me().username
        link = f"https://t.me/{bot_username}?start={user_id}"

        bot.reply_to(message,
            f"👥 Link mời của bạn:\n\n{link}\n\n"
            f"🎁 Mỗi người tham gia bạn nhận 3,000 VNĐ!"
        )