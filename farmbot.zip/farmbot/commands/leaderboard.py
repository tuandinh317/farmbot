from database import get_top

def register(bot):

    @bot.message_handler(commands=['top'])
    def top_cmd(message):
        users = get_top()

        text = "🏆 TOP GIÀU NHẤT\n\n"

        for i, u in enumerate(users, 1):
            text += f"{i}. {u['telegram_id']} - {u['vnd']:,} VNĐ\n"

        bot.reply_to(message, text)